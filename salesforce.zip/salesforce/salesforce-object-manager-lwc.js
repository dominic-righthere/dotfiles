// objectManager.js
import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

// Apex method imports (these will be defined in a corresponding Apex class)
import createCustomObject from '@salesforce/apex/ObjectManagerController.createCustomObject';
import createCustomField from '@salesforce/apex/ObjectManagerController.createCustomField';
import getCustomObjects from '@salesforce/apex/ObjectManagerController.getCustomObjects';
import getFieldTypes from '@salesforce/apex/ObjectManagerController.getFieldTypes';
import deleteCustomObject from '@salesforce/apex/ObjectManagerController.deleteCustomObject';
import deleteCustomField from '@salesforce/apex/ObjectManagerController.deleteCustomField';

export default class ObjectManager extends LightningElement {
    // Tracked properties for two-way binding
    @track objectName = '';
    @track objectLabel = '';
    @track objectPluralLabel = '';
    
    @track fieldName = '';
    @track fieldLabel = '';
    @track fieldType = '';
    @track selectedObject = '';
    
    @track customObjects = [];
    @track fieldTypes = [];
    @track customFields = [];

    // Lifecycle hook to load initial data
    connectedCallback() {
        this.loadCustomObjects();
        this.loadFieldTypes();
    }

    // Load existing custom objects
    async loadCustomObjects() {
        try {
            this.customObjects = await getCustomObjects();
        } catch (error) {
            this.showError('Error Loading Objects', error.body.message);
        }
    }

    // Load available field types
    async loadFieldTypes() {
        try {
            this.fieldTypes = await getFieldTypes();
        } catch (error) {
            this.showError('Error Loading Field Types', error.body.message);
        }
    }

    // Object creation handlers
    handleObjectNameChange(event) {
        this.objectName = event.target.value;
        // Auto-generate label and plural label if not specified
        if (!this.objectLabel) {
            this.objectLabel = this.formatLabel(this.objectName);
        }
        if (!this.objectPluralLabel) {
            this.objectPluralLabel = this.formatLabel(this.objectName) + 's';
        }
    }

    handleObjectLabelChange(event) {
        this.objectLabel = event.target.value;
    }

    handleObjectPluralLabelChange(event) {
        this.objectPluralLabel = event.target.value;
    }

    // Field creation handlers
    handleFieldNameChange(event) {
        this.fieldName = event.target.value;
        // Auto-generate field label if not specified
        if (!this.fieldLabel) {
            this.fieldLabel = this.formatLabel(this.fieldName);
        }
    }

    handleFieldLabelChange(event) {
        this.fieldLabel = event.target.value;
    }

    handleFieldTypeChange(event) {
        this.fieldType = event.target.value;
    }

    handleObjectSelection(event) {
        this.selectedObject = event.target.value;
        // Optionally load existing fields for selected object
        this.loadCustomFields(this.selectedObject);
    }

    // Create custom object
    async createObject() {
        // Validation
        if (!this.objectName || !this.objectLabel || !this.objectPluralLabel) {
            this.showError('Validation Error', 'Please fill in all object details');
            return;
        }

        try {
            const result = await createCustomObject({
                objectName: this.objectName,
                objectLabel: this.objectLabel,
                objectPluralLabel: this.objectPluralLabel
            });

            this.showSuccess('Object Created', `Custom object ${this.objectLabel} created successfully`);
            
            // Reset form and reload objects
            this.resetObjectForm();
            this.loadCustomObjects();
        } catch (error) {
            this.showError('Object Creation Failed', error.body.message);
        }
    }

    // Create custom field
    async createField() {
        // Validation
        if (!this.selectedObject || !this.fieldName || !this.fieldLabel || !this.fieldType) {
            this.showError('Validation Error', 'Please select an object and fill in all field details');
            return;
        }

        try {
            const result = await createCustomField({
                objectApiName: this.selectedObject,
                fieldName: this.fieldName,
                fieldLabel: this.fieldLabel,
                fieldType: this.fieldType
            });

            this.showSuccess('Field Created', `Custom field ${this.fieldLabel} created successfully`);
            
            // Reset form and reload fields
            this.resetFieldForm();
            this.loadCustomFields(this.selectedObject);
        } catch (error) {
            this.showError('Field Creation Failed', error.body.message);
        }
    }

    // Delete custom object
    async deleteSelectedObject() {
        if (!this.selectedObject) {
            this.showError('Deletion Error', 'Please select an object to delete');
            return;
        }

        try {
            await deleteCustomObject({ objectApiName: this.selectedObject });
            
            this.showSuccess('Object Deleted', `Custom object ${this.selectedObject} deleted successfully`);
            
            // Reset selection and reload objects
            this.selectedObject = '';
            this.loadCustomObjects();
        } catch (error) {
            this.showError('Object Deletion Failed', error.body.message);
        }
    }

    // Utility methods
    formatLabel(apiName) {
        // Convert camelCase or snake_case to Title Case
        return apiName
            .replace(/([A-Z])/g, ' $1')  // Insert space before capital letters
            .replace(/^./, str => str.toUpperCase())  // Capitalize first letter
            .replace(/_/g, ' ')  // Replace underscores with spaces
            .trim();
    }

    // Toast notification methods
    showSuccess(title, message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: 'success'
            })
        );
    }

    showError(title, message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: 'error'
            })
        );
    }

    // Form reset methods
    resetObjectForm() {
        this.objectName = '';
        this.objectLabel = '';
        this.objectPluralLabel = '';
    }

    resetFieldForm() {
        this.fieldName = '';
        this.fieldLabel = '';
        this.fieldType = '';
    }
}